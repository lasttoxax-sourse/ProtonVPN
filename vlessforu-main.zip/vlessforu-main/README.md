# 📡 VlessForU – Автоматическая подписка с рабочими VLESS/VMESS/Trojan

Этот репозиторий автоматически собирает и тестирует прокси-конфиги из публичных источников, оставляя только **реально работающие** серверы с задержкой менее 700 мс.  
Обновление происходит **каждый час** – вы всегда получаете свежий список активных узлов.

## 🚀 Готовая подписка для вашего клиента

Подписка доступна на сайте:
https://sub.vlessfo.ru

## Откуда берутся сервера?

Я тупо стягиваю их из открытых пабликов (спасибо igareck, Hidashimora и другим ребятам). Ссылки на источники есть в lol файле.

Каждый конфиг проходит проверку через реальный xray:
- Стучит на 3 сайта (1.1.1.1, Гугл, самсунг)
- Если хотя бы 2 ответили и пинг не выше 700 мс — сервер попадает в подписку

Дубликаты по IP/портам тоже вырезаются, чтобы не раздувать список.

## Что не так?

Автоматика не дает 100% гарантии. Бывает:
- Сервер падает между проверками (но подожди 20 минуток — он уползет)
- Твой оператор блокирует конкретный IP или SNI

Ничего идеального в этом мире нет, но так точно лучше, чем руками по 500 конфигов тыкать.

## Star History

<a href="https://www.star-history.com/?repos=bobrinaw%2Fvlessforu&type=date&legend=top-left">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=bobrinaw/vlessforu&type=date&theme=dark&legend=top-left" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=bobrinaw/vlessforu&type=date&legend=top-left" />
   <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=bobrinaw/vlessforu&type=date&legend=top-left" />
 </picture>
</a>

## 🤝 Благодарности

- [igareck](https://github.com/igareck/vpn-configs-for-russia) – за отличные сборники конфигов.
- [Hidashimora](https://github.com/Hidashimora/free-vpn-anti-rkn) – за дополнительные списки.
- Проект [Xray-core](https://github.com/XTLS/Xray-core) – за возможность реальной проверки.

## ⚠️ Лучше прочитай (отказ от ответственности)

Я собрал в кучу то, что другие люди выложили в открытый доступ. Я **не владею** этими серверами, **не контролирую** их, **ничего не гарантирую**.

В некоторых странах за обход блокировок могут спросить.

## Хочу помочь или поругаться

- По поводу **работы скрипта** — пиши в Issues (https://github.com/bobrinaw/vlessforu/issues)
- По поводу **мертвых серверов** — к тем, кто их публикует, я просто тестировщик

---
